//! Settings-only scroll physics, composed from ordinary clipped rectangles.
use super::*;
use std::collections::BTreeMap;
const STEP: f32 = 72.0;
const RUBBER: f32 = 140.0;
const SPRING_TENSION: f32 = 0.12;
struct Position {
    target: f32,
    maximum: f32,
    motion: Spring,
    release: Option<Instant>,
}
struct Scrolling {
    pages: BTreeMap<&'static str, Position>,
}
impl Service for Scrolling {
    fn new() -> Self {
        Self {
            pages: BTreeMap::new(),
        }
    }
    fn interval() -> Duration {
        Duration::from_millis(16)
    }
    fn update(&mut self) -> bool {
        let mut changed = false;
        for p in self.pages.values_mut() {
            if p.release.is_some_and(|t| Instant::now() >= t) {
                p.release = None;
                p.target = p.target.clamp(0.0, p.maximum);
                p.motion.to(p.target);
                changed = true;
            }
        }
        changed
    }
}
fn resisted(value: f32, max: f32) -> f32 {
    if value < 0.0 {
        -RUBBER * (1.0 - (-value * SPRING_TENSION / RUBBER).exp())
    } else if value > max {
        max + RUBBER * (1.0 - (-(value - max) * SPRING_TENSION / RUBBER).exp())
    } else {
        value
    }
}
fn wheel(id: &'static str, delta: f32, max: f32) {
    if delta == 0.0 || !delta.is_finite() {
        return;
    }
    let mut s = Scrolling::write();
    let p = s.pages.entry(id).or_insert_with(|| Position {
        target: 0.0,
        maximum: max,
        motion: Spring::slow(0.0, 0.7),
        release: None,
    });
    if p.maximum != max {
        p.target = p.target.clamp(0.0, max);
    }
    p.maximum = max;
    p.target = resisted(p.target + delta * STEP, max);
    p.motion.to(p.target);
    p.release = Some(Instant::now() + Duration::from_millis(110));
}
fn track_value(y: f32, max: f32, height: f32, thumb: f32) -> f32 {
    ((y - thumb / 2.0) / (height - thumb).max(1.0)).clamp(0.0, 1.0) * max
}
fn seek(id: &'static str, y: f32, max: f32, height: f32, thumb: f32) {
    let value = track_value(y, max, height, thumb);
    let mut s = Scrolling::write();
    let p = s.pages.entry(id).or_insert_with(|| Position {
        target: 0.0,
        maximum: max,
        motion: Spring::new(0.0),
        release: None,
    });
    p.maximum = max;
    p.target = value;
    p.motion.to(value);
    p.release = Some(Instant::now() + Duration::from_millis(80));
}
/// Current scroll offset of a page, for callers that only build what is visible.
pub(super) fn offset(id: &'static str) -> f32 {
    Scrolling::read()
        .pages
        .get(id)
        .map(|p| p.motion.precise_value().max(0.0))
        .unwrap_or(0.0)
}
pub(super) fn view(
    id: &'static str,
    content: impl amane::Widget + 'static,
    width: f32,
    height: f32,
) -> Rectangle {
    view_inner(id, content, width, height, true)
}

/// A smooth scroll viewport without the rail, for nested lists that should keep
/// their full width.
pub(super) fn view_plain(
    id: &'static str,
    content: impl amane::Widget + 'static,
    width: f32,
    height: f32,
) -> Rectangle {
    view_inner(id, content, width, height, false)
}

fn view_inner(
    id: &'static str,
    content: impl amane::Widget + 'static,
    width: f32,
    height: f32,
    rail: bool,
) -> Rectangle {
    let content_h = match content.height() {
        amane::Size::Fixed(h) => h,
        _ => height,
    };
    let max = (content_h - height).max(0.0);
    let state = Scrolling::read();
    let offset = state
        .pages
        .get(id)
        .map(|p| {
            let sampled = p.motion.precise_value();
            if p.maximum != max {
                sampled.clamp(0.0, max)
            } else {
                sampled
            }
        })
        .unwrap_or(0.0);
    drop(state);
    let content_width = if rail { width - 20.0 } else { width };
    let mut children: Vec<Box<dyn amane::Widget>> = children![
        Rectangle::new()
            .width(content_width)
            .height(content_h)
            .translate(0.0, -offset)
            .child(content)
    ];
    if rail {
        let thumb = if max > 0.0 {
            (height * height / content_h).max(36.0).min(height - 24.0)
        } else {
            height
        };
        let ty = if max > 0.0 {
            offset / max * (height - thumb)
        } else {
            0.0
        };
        let overshoot = if offset < 0.0 {
            -offset
        } else {
            (offset - max).max(0.0)
        };
        let visible_thumb = (thumb - overshoot * 0.25).max(24.0).min(height);
        let track_x = width - 12.0;
        let thumb_rect = Rectangle::new()
            .width(6.0)
            .height(visible_thumb)
            .translate(track_x + 3.0, ty)
            .radius(Full)
            .fill(crate::theme::palette().cyan)
            .scale(crate::feedback::scale(&format!("scroll-thumb:{id}")))
            .cursor(if max > 0.0 {
                amane::Grab
            } else {
                amane::Default
            })
            .on_drag(move |point| {
                if max > 0.0 {
                    crate::feedback::click(&format!("scroll-thumb:{id}"));
                    seek(id, point.y + ty, max, height, thumb)
                }
            });
        let track_visual = if max > 0.0 {
            Rectangle::new()
                .width(12.0)
                .height(height)
                .translate(track_x, 0.0)
                .radius(Full)
                .fill(crate::theme::surface())
                .clip()
                .child(thumb_rect)
        } else {
            Rectangle::new().width(12.0).height(height).translate(track_x, 0.0)
        };
        children.push(Box::new(
            Rectangle::new()
                .width(12.0)
                .height(height)
                .translate(track_x, 0.0)
                .cursor(if max > 0.0 {
                    amane::Grab
                } else {
                    amane::Default
                })
                .on_drag(move |point| {
                    if max > 0.0 {
                        seek(id, point.y, max, height, thumb)
                    }
                })
                .child(track_visual),
        ));
    }
    Rectangle::new()
        .width(width)
        .height(height)
        .clip()
        .on_scroll(move |scroll| wheel(id, scroll.y, max))
        .child(amane::Stack::new(children).width(width).height(height))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rubber_band_is_bounded_and_bidirectional() {
        assert!(resisted(-1000.0, 100.0) >= -RUBBER);
        assert!(resisted(1000.0, 100.0) <= 100.0 + RUBBER);
        assert_eq!(resisted(50.0, 100.0), 50.0);
        assert!(STEP > 15.0 * 3.0);
    }
    #[test]
    fn scrollbar_maps_track_to_content() {
        assert_eq!(track_value(-10.0, 1000.0, 400.0, 80.0), 0.0);
        assert_eq!(track_value(200.0, 1000.0, 400.0, 80.0), 500.0);
        assert_eq!(track_value(800.0, 1000.0, 400.0, 80.0), 1000.0);
    }
    #[test]
    fn overscroll_returns_to_endpoint() {
        let mut s = Scrolling::new();
        s.pages.insert(
            "test",
            Position {
                target: -40.0,
                maximum: 500.0,
                motion: Spring::new(-40.0),
                release: Some(Instant::now() - Duration::from_millis(1)),
            },
        );
        assert!(s.update());
        assert_eq!(s.pages["test"].target, 0.0);
        assert!(s.pages["test"].release.is_none());
    }
    #[test]
    fn upper_lower_bounds_are_continuous() {
        assert_eq!(resisted(0.0, 100.0), 0.0);
        assert_eq!(resisted(100.0, 100.0), 100.0);
    }
}
